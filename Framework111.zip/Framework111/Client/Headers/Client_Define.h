#pragma once

#ifndef __CLIENT_DEFINE_H__

#define WINCX 1600
#define WINCY 900



#define __CLIENT_DEFINE_H__
#endif