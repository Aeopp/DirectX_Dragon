#pragma once

#ifndef __CLIENT_ENUM_H__

enum class ESceneID
{
	Static,
	Logo,
	Stage,
	End
};

#define __CLIENT_ENUM_H__
#endif