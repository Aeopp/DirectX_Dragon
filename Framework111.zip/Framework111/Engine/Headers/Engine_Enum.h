#pragma once

#ifndef __ENGINE_ENUM_H__

enum class EDisplayMode
{ 
	Full,
	Window
};

#define __ENGINE_ENUM_H__
#endif